﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Entidades
{
    
    public enum EEstado { Ingresado, EnViaje, Entregado }
    public class Paquete : IMostrar<Paquete>
    {
        public delegate void DelegadoEstado(object o, EventArgs e);
        private string direccionEntrega;
        private EEstado estado;
        private string trackingID;

        
        public string DireccionEntrega
        {
            get { return this.direccionEntrega; }
            set { this.direccionEntrega = value; }
        }

        public EEstado Estado
        {
            get { return this.estado; }
            set { this.estado = value; }
        }

        public string TrackingID
        {
            get { return this.trackingID; }
            set { this.trackingID = value; }
        }


        public void MockCicloDeVida()
        {
            Thread.Sleep(10000);
            this.estado = EEstado.EnViaje;
            this.InformaEstado.Invoke(this, EventArgs.Empty);
            Thread.Sleep(10000);
            this.estado = EEstado.Entregado;
            this.InformaEstado.Invoke(this, EventArgs.Empty);
            PaqueteDAO.InsertarPaquete(this);
        }

        
        public string MostrarDatos(IMostrar<Paquete> elemento)
        {
            Paquete datos = (Paquete) elemento;
            return string.Format("{0} para {1}", datos.TrackingID, datos.DireccionEntrega);
        }

        public event DelegadoEstado InformaEstado;


        public Paquete(string direccionEntrega, string trackingID)
        {
            this.DireccionEntrega = direccionEntrega;
            this.TrackingID = trackingID;
            this.Estado = EEstado.Ingresado;
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            
            sb.AppendFormat("ID: {0} |", this.TrackingID);
            sb.AppendFormat(" DIR: {0}\n", this.DireccionEntrega);
            
            return sb.ToString();
        }

        public static bool operator ==(Paquete a, Paquete b)
        {
            bool retorno = false;
            if (a.TrackingID == b.TrackingID)
                retorno = true;
            return retorno;
        }

        public static bool operator !=(Paquete a, Paquete b)
        { return !(a == b); }

        
        
        

        
    }
}
