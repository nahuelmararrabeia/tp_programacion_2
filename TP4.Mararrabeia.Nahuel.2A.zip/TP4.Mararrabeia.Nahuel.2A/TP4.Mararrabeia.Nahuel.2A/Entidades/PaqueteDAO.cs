﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Entidades
{
    public static class PaqueteDAO
    {
        private static SqlCommand _comando;
        private static SqlConnection _conexion;

        public static bool InsertarPaquete(Paquete p)
        {
            bool retorno = false;
            _conexion = new SqlConnection(Properties.Settings.Default.Conexion);
            _conexion.Open();
            try
            {
                string insert = "insert into Paquetes (direccionEntrega, trackingId, alumno) ";
                string values = "values ('" + p.DireccionEntrega + "','" + p.TrackingID + "' , 'Mararrabiea_Nahuel')";
                _comando = new SqlCommand(insert + values, _conexion);                
                _comando.ExecuteNonQuery();
                retorno = true;
            }
            catch
            {
                MessageBox.Show("Error al ingresar el paquete " + p.ToString() + " a la base de datos");
            }
            finally { _conexion.Close(); }
            return retorno;
        }


        static PaqueteDAO()
        {
            _conexion = new SqlConnection();            
        }





        
    }
}
