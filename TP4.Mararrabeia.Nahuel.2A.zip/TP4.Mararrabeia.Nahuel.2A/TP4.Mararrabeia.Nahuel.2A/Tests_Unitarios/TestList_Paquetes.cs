﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Entidades;

namespace Tests_Unitarios
{
    [TestClass]
    public class TestList_Paquetes
    {
        [TestMethod]
        public void ListaInstanciada()
        {
            //arrange
            Correo c;

            //act
            c = new Correo();

            //assert
            Assert.IsNotNull(c.Paquetes);


                        
        }
    }
}
