﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Entidades;

namespace Tests_Unitarios
{
    [TestClass]
    public class TestTrackingId
    {
        [TestMethod]
        [ExpectedException(typeof(TrackingIdRepetidoException))]
        public void TestIdRepetido()
        {
            // arrange
            Paquete p1 = new Paquete("", "1");
            Paquete p2 = new Paquete("", "1");
            Correo c = new Correo();

            //act
            c += p1;
            c += p2; 
        }
    }
}
