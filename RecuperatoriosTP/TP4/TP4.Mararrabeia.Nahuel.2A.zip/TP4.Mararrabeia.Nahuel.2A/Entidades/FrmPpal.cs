﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Entidades
{
    public partial class FrmPpal : Form
    {
        Correo correo;
        public FrmPpal()
        {
            InitializeComponent();
            correo = new Correo();
            lstEstadoEntregado.ContextMenuStrip = contextMenuStrip1;
        }

        
        private void ActualizarEstados()
        {
            lstEstadoEntregado.Items.Clear();
            lstEstadoEnViaje.Items.Clear();
            lstEstadoIngresado.Items.Clear();
            foreach (Paquete i in correo.Paquetes)
            {
                switch (i.Estado)
                {
                    case EEstado.Ingresado:
                        lstEstadoIngresado.Items.Add(i);
                        break;
                    case EEstado.EnViaje:
                        lstEstadoEnViaje.Items.Add(i);
                        break;
                    case EEstado.Entregado:
                        lstEstadoEntregado.Items.Add(i);
                        break;
                    default:
                        break;
                }
            }
        }

        private void MostrarInformacion<T>(IMostrar<T> elemento)
        {
            string path = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + "\\salida.txt";
            if (elemento != null)
            {
                rtbMostrar.AppendText(elemento.MostrarDatos(elemento));                
            }else
            { throw new Exception("Elemento nulo"); }
            elemento.MostrarDatos(elemento).Guardar(path);
 
        }

        private void paq_InformaEstado(object sender, EventArgs e)
        {

            if (this.InvokeRequired) {
                Paquete.DelegadoEstado d = new Paquete.DelegadoEstado(paq_InformaEstado); 
                this.Invoke( d, new object[] {sender, e} ); }
            else { this.ActualizarEstados(); } 
        }

        
        private void btnAgregar_Click(object sender, EventArgs e)
        {
            Paquete paquete = new Paquete(txtDireccion.Text, mtxtTrackingID.Text);
            paquete.InformaEstado += new Paquete.DelegadoEstado(paq_InformaEstado);
            correo += paquete;
            this.ActualizarEstados();
            txtDireccion.Text = "";
            mtxtTrackingID.Text = "";
        }

        private void FrmPpal_FormClosed(object sender, FormClosedEventArgs e)
        {
            correo.FinEntregas();
        }

        private void btnMostrarTodos_Click(object sender, EventArgs e)
        {
            try{
            this.MostrarInformacion<List<Paquete>>((IMostrar<List<Paquete>>)correo);
            }
            catch (InvalidCastException ex) { throw new InvalidCastException(ex.Message); }
        }
        

        private void mostrarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.MostrarInformacion<Paquete>((IMostrar<Paquete>)lstEstadoEntregado.SelectedItem);
        }
    }
}
