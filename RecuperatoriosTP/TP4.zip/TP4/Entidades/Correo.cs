﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Threading;

namespace Entidades
{
    public class Correo : IMostrar<List<Paquete>>
    {
        private List<Thread> mockPaquetes;
        private List<Paquete> paquetes;
        public List<Paquete> Paquetes
        {
            get { return this.paquetes; }
            set { this.paquetes = value; }
        }
        public Correo()
        {
            this.paquetes = new List<Paquete>();
            this.mockPaquetes = new List<Thread>();
        }


        public void FinEntregas()
        {
            foreach (Thread i in this.mockPaquetes)
            { i.Abort(); }
        }        
        

        public string MostrarDatos(IMostrar<List<Paquete>> elementos)
        {
            string datos = "";
            
            try
            {
                foreach (Paquete i in ((Correo)elementos).Paquetes)
                { datos += string.Format("{0} para {1} ({2})\n", i.TrackingID, i.DireccionEntrega, i.Estado.ToString()); }
            }
            catch (InvalidCastException e) { throw new InvalidCastException(e.Message); }
            return datos;   
        }


        public static Correo operator +(Correo c, Paquete p)
        {
            bool idTest = true;
            foreach (Paquete i in c.Paquetes)
            {
                if(i == p)
                {
                    idTest = false;
                    break;
                }
            }

            if (idTest) { c.paquetes.Add(p); }
            else { throw new TrackingIdRepetidoException("TrackingId de paquete ya existe"); }
            Thread hilo = new Thread(p.MockCicloDeVida);
            c.mockPaquetes.Add(hilo);
            hilo.Start();
            return c;
        }

        



    }
}
