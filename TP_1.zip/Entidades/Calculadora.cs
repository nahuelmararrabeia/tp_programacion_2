﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Calculadora
    {
        private static string ValidarOperador(string op)
        {
            string retorno = "+";
            if (op == "+" || op == "-" || op == "*" || op == "/")
                retorno = op;

            return retorno;
        }

        public static double Operar(Numero num1, Numero num2, string operador)
        {
            string op = ValidarOperador(operador);
            double resultado = 0;
            switch (op)
            {
                case "+":
                    resultado = num1 + num2;
                    break;
                case "-":
                    resultado = num1 - num2;
                    break;
                case "*":
                    resultado = num1 * num2;
                    break;
                case "/":
                    resultado = num1 / num2;
                    break;
                default:
                    break;
            }
            return resultado;
        }
    }
}
