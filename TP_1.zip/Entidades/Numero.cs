﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Numero
    {
        private double numero;

        private double ValidarNumero(string strNumero)
        {
            double retorno = 0;
            double salida;
            if (double.TryParse(strNumero, out salida) == true)
                retorno = salida;

            return retorno;
        }



        private string SetNumero
        {
            set
            {
                numero = this.ValidarNumero(value);
            }
        }

                

        public string BinarioDecimal(string bin)
        {
            int x = bin.Length - 1;
            int dec = 0;
            string retorno = "";

            for (int i = 0; i < bin.Length; i++)
            {
                if (int.Parse(bin.Substring(i, 1)) == 1)
                {
                    dec = dec + int.Parse(System.Math.Pow(2, double.Parse(x.ToString())).ToString());
                }
                x--;
            }
            retorno = dec.ToString();
            return retorno;
        }




        public string DecimalBinario(double numero)
        {
            numero = Convert.ToInt32(numero);
            string binario = "";

            if (numero > 0)
            {
                while (numero > 0)
                {
                    if (numero % 2 == 0)
                        binario = "0" + binario;
                    else
                        binario = "1" + binario;

                    numero = (int)numero / 2;
                }
            }
            else if (numero == 0)
                binario = "0";
            else
                binario = "Valor invalido";

            return binario;
        }


        public string DecimalBinario(string numero)
        {
            double num = double.Parse(numero);
            numero = DecimalBinario(num);

            return numero;
        }

        public Numero()
            : this(0)
        { }

        public Numero(double numero)
        {
            SetNumero = numero.ToString();
        }

        public Numero(string numero)
        {
            SetNumero = numero;
        }


        public static double operator -(Numero n1, Numero n2)
        {
            double resultado = n1.numero - n2.numero;
            return resultado;
        }

        public static double operator +(Numero n1, Numero n2)
        {
            double resultado = n1.numero + n2.numero;
            return resultado;
        }

        public static double operator *(Numero n1, Numero n2)
        {
            double resultado = n1.numero * n2.numero;
            return resultado;
        }

        public static double operator /(Numero n1, Numero n2)
        {
            double resultado = n1.numero / n2.numero;
            return resultado;
        }
    }
    }


 